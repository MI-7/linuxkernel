#ifndef SHELL_H
#define	SHELL_H

unsigned int shell();
unsigned int processargument();

#endif
