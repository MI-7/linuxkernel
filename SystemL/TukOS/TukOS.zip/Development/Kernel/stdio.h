#ifndef STDIO_H
#define	STDIO_H

unsigned char getchar();
unsigned int printchar(unsigned char);

#endif
