#ifndef MEMORY_H
#define	MEMORY_H

unsigned int mapmemory(unsigned char*, unsigned int);
unsigned int memset(unsigned char*, unsigned char, unsigned int);

#endif
