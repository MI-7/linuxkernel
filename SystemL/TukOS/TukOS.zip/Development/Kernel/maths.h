#ifndef MATHS_H
#define	MATHS_H

int pow(int, int);

#endif
