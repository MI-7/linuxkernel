#ifndef KEYBOARD_H
#define	KEYBOARD_H

unsigned char convert_scancode_ascii(unsigned char);
unsigned char keyboardbuffer(unsigned char, unsigned char);

#endif
